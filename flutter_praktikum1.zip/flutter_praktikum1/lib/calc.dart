import 'package:flutter/material.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Kalkulator Kabataku'),
        ),
        body: const KalkulatorForm(),
      ),
    );
  }
}

class KalkulatorForm extends StatefulWidget {
  const KalkulatorForm({super.key});

  @override
  State<KalkulatorForm> createState() => _KalkulatorFormState();
}

class _KalkulatorFormState extends State<KalkulatorForm> {
  final TextEditingController _angka1Controller = TextEditingController();
  final TextEditingController _angka2Controller = TextEditingController();

  String _hasil = '';

  @override
  void dispose() {
    _angka1Controller.dispose();
    _angka2Controller.dispose();
    super.dispose();
  }

  void _hitung(String operasi) {
    double? a = double.tryParse(_angka1Controller.text);
    double? b = double.tryParse(_angka2Controller.text);

    if (a == null || b == null) {
      setState(() {
        _hasil = 'Masukkan angka yang valid!';
      });
      return;
    }

      double result = 0;
      String simbol = '';

      switch (operasi) {
        case 'tambah':
          result = a + b;
          simbol = '+';
          break;
        case 'kurang':
          result = a - b;
          simbol = '-';
          break;
        case 'kali':
          result = a * b;
          simbol = 'x';
          break;
        case 'bagi':
          if (b == 0) {
            setState(() {
              _hasil = 'Tidak bisa dibagi 0!';
            });
            return;
          }
          result = a / b;
          simbol = ':';
          break;
      }

      setState(() {
        _hasil = '$a $simbol $b = $result';
      });
    }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Angka 1 :'),
          const SizedBox(height: 8),
          TextField(
            controller: _angka1Controller,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
              hintText: 'Masukkan angka pertama',
            ),
          ),
          const SizedBox(height: 16),
          const Text('Angka 2 :'),
          const SizedBox(height: 8),
          TextField(
            controller: _angka2Controller,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
              hintText: 'Masukkan angka kedua',
            ),
          ),
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              ElevatedButton(
                onPressed: () => _hitung('kali'),
                child: const Text('Kali (x)'),
              ),
              ElevatedButton(
                onPressed: () => _hitung('bagi'),
                child: const Text('Bagi (:)'),
              ),
              ElevatedButton(
                onPressed: () => _hitung('tambah'),
                child: const Text('Tambah (+)'),
              ),
              ElevatedButton(
                onPressed: () => _hitung('kurang'),
                child: const Text('Kurang (-)'),
              ),
            ],
          ),
          const SizedBox(height: 24),
          Text(
            'Hasil : $_hasil',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }
}